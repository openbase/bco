#!/bin/bash

echo "reset user activity class db..."
git reset --hard
git clean -f
