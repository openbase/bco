# bco.registry.unit-template-db
Global unit template registry database.
