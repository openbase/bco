#!/bin/bash

echo "reset unit template db..."
git reset --hard
git clean -f
