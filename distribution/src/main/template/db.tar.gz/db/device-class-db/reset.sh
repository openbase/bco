#!/bin/bash

echo "reset device class db..."
git reset --hard
git clean -f
