# bco.registry.device-class-db
Global device class registry database.
