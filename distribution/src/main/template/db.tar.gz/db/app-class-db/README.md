# bco.registry.app-class-db
Global app class registry database.
