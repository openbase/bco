#!/bin/bash

echo "reset app class db..."
git reset --hard
git clean -f
