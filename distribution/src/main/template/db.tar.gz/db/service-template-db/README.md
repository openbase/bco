# bco.registry.service-template-db
Global unit template registry database.
