#!/bin/bash

echo "reset service template db..."
git reset --hard
git clean -f
