#!/bin/bash

echo "reset agent class db..."
git reset --hard
git clean -f
