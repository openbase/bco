# bco.registry.agent-class-db
Global agent class registry database.
